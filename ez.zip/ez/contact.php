<link rel="stylesheet" type="text/css" href="css/submitstyle.css">
<html>
    <body>
<?php
   if(isset($_POST["email"])){ 
    $email = $_POST["email"];   
    $EmailTo = "info@eazytechss.com";
    $headers ="From: ".' '.$email;
    $subject = $_POST["subject"];
    $body = "Myself ".' '.$_POST["fname"].' '.$_POST["lname"].' '.$_POST["message"];
   /*$fname = $_POST["fname"].' '.$_POST["lname"];*/
   
   if ( mail($EmailTo,$subject, $body, $headers)) {
      echo'<div class="success-msg">
  <i class="fa fa-check"></i>
  Successfully Sent!
</div>';
header("Refresh:0; url= index.php");
   } else {
      echo '<div class="success-msg">
  <i class="fa fa-check"></i>
  Not Sent
</div>';
header("Refresh:0; url= index.php");
   }
}
else{
    echo '<div class="success-msg">
  <i class="fa fa-check"></i>
  Not Sent
</div>';
header("Refresh:0; url= index.php");
}
?>

    </body>
</html>